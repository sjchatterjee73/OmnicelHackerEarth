package driver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmnicelRestProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
